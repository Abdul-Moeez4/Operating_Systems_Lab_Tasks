#include <iostream>
using namespace std;
#include <stdio.h>
#include<pthread.h>



int global_Array[30]; 

long mul_result = 1;

long add_result = 0;

void *calculate_mul()
{

for (int i=0; i<30; i++)
{
    mul_result = mul_result * global_Array[i];
    cout<<mul_result<<endl;
}
pthread_exit(NULL);

}

void *calculate_add()
{

for (int i=0; i<30; i++)
{
    add_result = add_result + global_Array[i];
    cout<<add_result<<endl;
}

pthread_exit(NULL);


}
int main(){

printf("this is main funtion\n");

pthread_t thread1;

pthread_t thread2;

pthread_create (&thread1,NULL,calculate_mul, NULL);

pthread_create (&thread2,NULL,calculate_add, NULL);


    pthread_join (thread1,NULL);
    
     pthread_join (thread2,NULL);





return 0;



}
