#include <iostream>
using namespace std;
#include <stdio.h>
#include<pthread.h>


void *threadfun(void *arg)
{


printf("Hello my name is Thread and my value %ld\n", pthread_self());


}

int main()
{
printf("this is main funtion\n");

int n;
cout<<"Enter a postive integer"<<endl;

cin>>n;

if (n < 0)
{
    cout<<"Enter a postive integer next time: "<<endl;
}

pthread_t thread1;
for (int i=0; i<n; i++)
{
    pthread_create (&thread1,NULL,threadfun, (void *) &i );
}


    pthread_join (thread1,NULL);



return 0;



}
