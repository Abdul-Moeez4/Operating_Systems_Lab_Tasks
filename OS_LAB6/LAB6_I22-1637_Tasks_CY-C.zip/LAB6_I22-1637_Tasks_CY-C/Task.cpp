#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstdlib>
#include <ctime>
using namespace std;

//simulate election process

//assume there are three candidates, A, B AND C SO GUESS MAKE A CONSTANT OF THREE CANDIDATES

const int NumOfCandidates = 3;

const char Candidates[] = {'A', 'B', 'C'};


int main()
{
	int pipefd[2];  //pipe[0] for reading (checking votes? i guess), pipe[1] would be for voting

	if (pipe(pipefd) == -1)
	{
		perror("pipe");
		exit(1);
	}
	
	int voters;
	cout<<"Enter number of voters: ";
	
	cin>>voters;
	
	
	//making an array of votecount having size of the no of candidates being 3
	int voteCount[NumOfCandidates] = {0};
	
	
	
	for (int i=0; i<=voters; i++)
	{
		pid_t pid = fork();
		srand(time(0) + getpid());
		
		if (pid == -1)
		{
			cout<<"Fork failed"<<endl;
			return 1;
		}
		else if (pid == 0)
		{
		
			close(pipefd[0]);  //close reading pipe
			
			//assigning a candidate (no idea how to expalin this)
			int candidate = rand() % NumOfCandidates;
			
			write(pipefd[1], &candidate, sizeof(candidate));
			
			close(pipefd[1]);
			
			exit(0);
		}
	else if (pid == 0) // Child process
	{ 
		
            close(pipefd[0]); // Closing off readpipe

            int candidate = rand() % NumOfCandidates;
            write(pipefd[1], &candidate, sizeof(candidate)); // Write the chosen candidate to the pipe

            close(pipefd[1]); // Close the write end of the pipe for the child
            exit(0);
        }
    }

    close(pipefd[1]); // Close the write end of the pipe for the parent


    for (int i = 0; i < voters; i++) {
        int vote;
        read(pipefd[0], &vote, sizeof(vote)); // Read the chosen candidate from the pipe

        // Increment the vote count for the corresponding candidate
        switch (vote) {
            case 0:
                voteCount[0]++;
                break;
            case 1:
                voteCount[1]++;
                break;
            case 2:
                voteCount[2]++;
                break;
            default:
                cout << "Invalid vote received!" << endl;
                break;
        }
    }

    close(pipefd[0]); // Close the read end of the pipe for the parent


    cout << " Results:" << endl;
    for (int i = 0; i < NumOfCandidates; i++) {
        cout << Candidates[i] << ": " << voteCount[i] << " votes" << endl;
    }

    // Determine the winner
    int maxVotes = 0;
    char winner;
    for (int i = 0; i < NumOfCandidates; i++) {
        if (voteCount[i] > maxVotes) {
            maxVotes = voteCount[i];
            winner = Candidates[i];
        }
    }
    cout << "The winner is Candidate " << winner << endl;

    // Wait for all child processes to finish
    for (int i = 0; i < voters; i++) {
        wait(NULL);
    }

    return 0;
}	
	


