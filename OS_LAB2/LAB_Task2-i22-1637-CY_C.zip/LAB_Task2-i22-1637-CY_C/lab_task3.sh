#!/bin/bash
date

echo "Name: "$1

echo "Total Marks: "$2

echo "ENglish: "$3

echo "Urdu: "$4

echo "Maths: "$5

exit 0 
