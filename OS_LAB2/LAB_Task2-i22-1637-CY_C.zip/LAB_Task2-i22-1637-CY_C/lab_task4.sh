#!/bin/bash

cd

cd Desktop

rm ./3rd/dummy3.txt
rm ./2nd/dummy2.txt

