#!/bin/bash

touch lab_task2.txt
echo 1 >> lab_task2.txt
echo 2 >> lab_task2.txt
echo 3 >> lab_task2.txt
echo 4 >> lab_task2.txt
echo 5 >> lab_task2.txt
echo 6 >> lab_task2.txt
echo 7 >> lab_task2.txt
echo 8 >> lab_task2.txt
echo 9 >> lab_task2.txt

sort -nr lab_task2.txt
