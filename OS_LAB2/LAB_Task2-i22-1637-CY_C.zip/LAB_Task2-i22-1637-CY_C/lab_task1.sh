#!/bin/bash
touch FROM
touch TO

#writing details in FROM FILE
echo "My name is Abdul Moeez Siddiqui, part of OS CY-C LAB" >> FROM

#copy contents of FROM and shift to TO
cp FROM TO

#remove FROM FILE
rm FROM

#rename TO FILE to FINAL_FILE
mv TO FINAL_FILE
