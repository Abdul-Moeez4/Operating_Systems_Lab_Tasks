#include <iostream>
#include <thread>
#include <mutex>
#include <queue>
#include <cstdlib>
#include <ctime>

using namespace std;

pthread_mutex_t mutex1;

int queue_size = 10;
int min_pages = 10;
int max_pages = 30;
int add_pages = 5;

queue<int> printer1;
queue<int> printer2;

void* functionLabor(void* wo) {
    int tid = *((int *)wo);
    queue<int>* printerQueue;
    if (tid == 1) {
        printerQueue = &printer1;
    }
    else {
        printerQueue = &printer2;
    }

    while (printerQueue->empty()) {
        // Adding papers to both printers
        for (int i = 0; i < add_pages; ++i) {
            pthread_mutex_lock(&mutex1);
            printerQueue->push(rand() % (max_pages - min_pages + 1) + min_pages); // Adding random pages
            pthread_mutex_unlock(&mutex1);
        }
        this_thread::sleep_for(chrono::seconds(5)); // Adding papers every 5 seconds
    }
}

void* functionPrint(void* mo) {
    int tid = *((int *)mo);
    queue<int>* printerQueue;
    if (tid == 1) {
        printerQueue = &printer1;
    }
    else {
        printerQueue = &printer2;
    }
    while (true) {
        if (!printerQueue->empty()) {
            pthread_mutex_lock(&mutex1);
            cout << "Printer " << tid << ": Printing document with Page Number " << printerQueue->front() << endl;
            printerQueue->pop();
            pthread_mutex_unlock(&mutex1);
        }
        else {
            pthread_mutex_lock(&mutex1);
            cout << "Printer " << tid << ": Out of Paper." << endl;
            pthread_mutex_unlock(&mutex1);
            this_thread::sleep_for(chrono::seconds(5)); // Sleep for a while if the queue is empty
        }
    }
}

int main() {
    pthread_mutex_init(&mutex1, NULL);

    pthread_t thread1, thread2, thread3, thread4;
    int tid1 = 1, tid2 = 2;

    pthread_create(&thread1, NULL, functionLabor, (void*)&tid1);
    pthread_create(&thread2, NULL, functionLabor, (void*)&tid2);
    pthread_create(&thread3, NULL, functionPrint, (void*)&tid1);
    pthread_create(&thread4, NULL, functionPrint, (void*)&tid2);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);

    pthread_mutex_destroy(&mutex1);
    return 0;
}
