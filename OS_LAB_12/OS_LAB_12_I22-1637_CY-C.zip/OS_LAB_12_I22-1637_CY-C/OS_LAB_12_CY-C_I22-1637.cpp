#include <iostream>
#include <semaphore.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>  //for sleep 
using namespace std;




int total_cars = 15;

sem_t bridge;

void* cross_bridge(void* mo)
{
    int car_num = *(int *)mo;
    

    cout<<"\nCar number: "<< car_num <<" waiting to cross bridge ";

    //wait (sort of entry section) //acts as wait(), decrements as resource being used
    sem_wait(&bridge);

    //c.s (critical section, crossing bridge)
    cout<<"\nCar number: "<< car_num <<" crossing bridge ";

    sleep(2); //sleep for 2 seconds
    cout<<endl;
    
    cout<<"\nCar number: "<< car_num <<" crossed bridge";

    sem_post(&bridge); //acts as signal(), increments after reosurce been used

    return NULL;
}



int main()
{
    sem_init(&bridge, 0, 3);

    pthread_t thread[total_cars];

    for (int i=0; i < total_cars; i++)
    {
        int * p= (int *) malloc(sizeof(int));
        *p=i;
        pthread_create(&thread[i], NULL, cross_bridge, p);
    }

    //join
    for (int i = 0; i < total_cars; i++)
    {
        pthread_join(thread[i], NULL);
    }

    sem_destroy(&bridge);
}