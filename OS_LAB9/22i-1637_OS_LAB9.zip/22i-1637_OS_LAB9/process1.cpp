// process1.cpp
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <iostream>
using namespace std;

int main() {
    char str[256];
    int fifo_write, fifo_read;

    // open "pipe_one" with WRITE only mode
    fifo_write = open("pipe_one", O_WRONLY);

    // open "pipe_two" with READ only mode
    fifo_read = open("pipe_two", O_RDONLY);

    // check if open calls were successful
    if (fifo_write < 0 || fifo_read < 0) {
        cout << "Error opening files" << endl;
        return 1;
    }

    while (true) {
        // Write
        cout << "Process 1 (Writer): ";
        cin.getline(str, sizeof(str));
        write(fifo_write, str, strlen(str) + 1);

        // Check for abort
        if (strcmp(str, "abort") == 0)
            break;

        // Read
        read(fifo_read, str, sizeof(str));
        cout << "Process 1 (Reader): " << str << endl;

        // Check for abort
        if (strcmp(str, "abort") == 0)
            break;
    }

    // Close file descriptors
    close(fifo_write);
    close(fifo_read);

    return 0;
}

