// process2.cpp
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <iostream>
using namespace std;

int main() {
    char str[256];
    int fifo_write, fifo_read;

    // open "pipe_one" with READ only mode
    fifo_read = open("pipe_one", O_RDONLY);

    // open "pipe_two" with WRITE only mode
    fifo_write = open("pipe_two", O_WRONLY);

    // check if open calls were successful
    if (fifo_read < 0 || fifo_write < 0) {
        cout << "Error opening files" << endl;
        return 1;
    }

    while (true) {
        // Read
        read(fifo_read, str, sizeof(str));
        cout << "Process 2 (Reader): " << str << endl;

        // Check for abort
        if (strcmp(str, "abort") == 0)
            break;

        // Write
        cout << "Process 2 (Writer): ";
        cin.getline(str, sizeof(str));
        write(fifo_write, str, strlen(str) + 1);

        // Check for abort
        if (strcmp(str, "abort") == 0)
            break;
    }

    // Close file descriptors
    close(fifo_read);
    close(fifo_write);

    return 0;
}

