#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

pthread_mutex_t mutex; 

int bank_account_money = 100;

void* width_draw(void* tid)
{
    for (int i=0; i<10; i++)
    {
        if (bank_account_money < 10)
        {
            cout<<"Insufficient funds"<<endl;
        }
        pthread_mutex_lock(&mutex);
        int readbalance = bank_account_money;
        cout<<"The balance before withdrawal thread:  "<< bank_account_money<<endl;
        readbalance -= 10;
        sleep(1);
        bank_account_money = readbalance;
        cout<<"The balance after withdrawal thread:  "<< bank_account_money<<endl;
        sleep(1);   
        pthread_mutex_unlock(&mutex);
    }   
}

void* deposit(void* tid)
{
    for (int i=0; i< 10; i++)
{   
    pthread_mutex_lock(&mutex);
    int readbalance = bank_account_money;
    cout<<"The balance before depositing thread" << bank_account_money<<endl;
    readbalance += 11;
    sleep(1);
    bank_account_money = readbalance;
    cout<<"The balance after deposit thread" << bank_account_money<<endl;
    sleep(1);
    pthread_mutex_unlock(&mutex);
}
}


int main()
{
    pthread_t thread1;
    pthread_t thread2;
    pthread_t thread3;
    pthread_t thread4;

    //initlise mutex
    pthread_mutex_init(&mutex, NULL);

    //create threads
    //generates 4 threads: two withdrawal threads and two depositing threads
    pthread_create(&thread1, NULL, width_draw, NULL);  //withdraw thread1
    
    pthread_create(&thread2, NULL, width_draw, NULL); //withdraw thread2
    
    pthread_create(&thread3, NULL, deposit, NULL); //deposit thread1
    
    pthread_create(&thread4, NULL, deposit, NULL); //deposit thread2

    //join threads
    pthread_join(thread1, NULL);
   pthread_join(thread2, NULL);
   pthread_join(thread3, NULL);
   pthread_join(thread4, NULL);

    //destry mutex to free space (?)
    pthread_mutex_destroy(&mutex);

}