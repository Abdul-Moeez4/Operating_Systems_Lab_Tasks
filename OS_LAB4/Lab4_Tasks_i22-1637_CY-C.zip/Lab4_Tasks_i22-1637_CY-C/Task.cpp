#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
using namespace std;

//5 commands chosen would be ls, cat,echo,pwd,man 

//take input asking user to choose from one of the 5 commands

int main()
{
	string user_input;
	
	cout<<"You have an option to choose from from 5 commands: "<<endl;
	cout<<"ls, cat,echo ,pwd or man or execute file by typing file "<<endl;
	
	cout<<"Choose your command: ";
	//do while so can input as many commands until user inputs "EXIT"
	do {
		cin>>user_input; 
	
		pid_t pid = fork();
		if (pid == 0)
		{
			//child process, take input
			if (user_input == "ls")
			{	
				cout<<"I am Child process"<<endl;
				execl( "/bin/ls","ls","/home/abdul_moeez4/Downloads", NULL); //abdul_moeez4 is identity/user name
				exit(1);
			}
			else if (user_input == "cat")
			{	
				char* argv[] = {"cat", "/home/abdul_moeez4/Desktop/sample.txt",NULL}; //contains a sample.txt file in Desktop dir
				execvp("cat",argv);
				exit(1);
			}
			else if (user_input == "man")
			{
				char* args[] = {"/usr/bin/man", "ls",NULL}; // basically does "man ls" command
				execv("/usr/bin/man", args);
				exit(1);
			}
			else if (user_input == "pwd")
			{
				execlp("pwd", "pwd", "/home/abdul_moeez4/Desktop", NULL); // basically show full path directory
				exit(1);
			}
			else if(user_input == "echo")
			{
				char *env[] = {"export TERM=vt100" ,"PATH=/bin:/usr/bin",NULL};
				execle("/bin/echo", "echo", "THIS IS EXCLE()", NULL, env); 
				exit(1);
			}
			else if(user_input == "file")  //excutes a file
			{
				execl( "/home/abdul_moeez4/Desktop/a.out","./a.out",NULL);  // do g++ hello.cpp -o a.out, which creates a.out exe and bring it to desktop and then inpiut file
				exit(1);
			}
		}
		else
		{
			wait(NULL);
		}
		
	} while(user_input!="EXIT");	
}	
