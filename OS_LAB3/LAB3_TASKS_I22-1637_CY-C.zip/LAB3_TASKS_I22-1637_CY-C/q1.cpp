#include <iostream>
#include <sys/wait.h>
#include<unistd.h>
using namespace std;


int num_iterations = 6;
int count = 0;
int main()
{
	for (int i=0; i<num_iterations; i++)
	{
		pid_t pid = fork();
		
		if (pid == 0)
		{
			//child process
			cout<<"Hello"<<endl;
			
		}
		else if (pid < 0 )
		{
			pid_t wpid;
			int status;
			while ( (wpid=wait(&status)) > 0 );
		}
		
	}
	
	
}
