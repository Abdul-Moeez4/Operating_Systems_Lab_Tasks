#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int calculate_d_times_a(int d, int a) {
    return d * a;
}

int calculate_a_plus_b(int a, int b) {
    return a + b;
}

int calculate_c_minus_a(int c, int a) {
    return c - a;
}

int main() {
    int a = 1, b = 6, c = 3, d = 7;
    int result;

    // Create first child to calculate (d*a)
    int pid1 = fork();

    if (pid1 == 0) {
        // Child 1 process
        result = calculate_d_times_a(d, a);
        cout << "Child 1 Result: " << result << endl;
        return result;
    } else {
        // Parent process
        // Create second child to calculate (a+b)
        int pid2 = fork();

        if (pid2 == 0) {
            // Child 2 process
            int a_plus_b = calculate_a_plus_b(a, b);
            cout << "Child 2 Result (a+b): " << a_plus_b << endl;

            // Create grandchild to calculate (c-a)
            int pid_grandchild = fork();

            if (pid_grandchild == 0) {
                // Grandchild process
                int c_minus_a = calculate_c_minus_a(c, a);
                cout << "Grandchild Result (c-a): " << c_minus_a << endl;
                return c_minus_a;
            } else {
                // Child 2 process
                int status;
                waitpid(pid_grandchild, &status, 0);
                int grandchild_result = WEXITSTATUS(status);
                int final_result = a_plus_b + grandchild_result;
                cout << "Child 2 Final Result [(a+b) + (c-a)]: " << final_result << endl;
                return final_result;
            }
        } else {
            // Parent process
            int status1, status2;
            waitpid(pid1, &status1, 0);
            waitpid(pid2, &status2, 0);
            int child1_result = WEXITSTATUS(status1);
            int child2_result = WEXITSTATUS(status2);
            result = child1_result * child2_result;
            cout << "Final Result of Equation A: " << result << endl;
        }
    }

    return 0;
}

