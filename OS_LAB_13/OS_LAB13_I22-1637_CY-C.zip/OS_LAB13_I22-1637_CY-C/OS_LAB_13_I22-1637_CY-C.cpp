#include <iostream>
using namespace std;
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

int total_people = 20;

sem_t seats;


void * restaurant(void* wo)
{
    int people = *((int *)wo);


    cout<< "\n" << people<< " People waiting to eat";

    //wait (sort of entry section) //acts as wait(), decrements as resource being used
    sem_wait(&seats);

    //c.s (critical section, eating)
    cout<< "\n" << people << "eating";

    sleep(2); //sleep for 2 seconds
    cout<<endl;
    
    cout<<"\n" << people << "have eaten";

    sem_post(&seats); //acts as signal(), increments after reosurce been used

    return NULL;
}
    


int main()
{
    sem_init(&seats, 0, 10);

    pthread_t threads[total_people];

    for (int i = 1; i <=total_people; i++)
    {
        int * p= (int *) malloc(sizeof(int));
        *p=i;
        pthread_create(&threads[i], NULL, restaurant, p);
    }

    for (int i=0; i<total_people; i++)
    {
        pthread_join(threads[i], NULL);
    }

}

