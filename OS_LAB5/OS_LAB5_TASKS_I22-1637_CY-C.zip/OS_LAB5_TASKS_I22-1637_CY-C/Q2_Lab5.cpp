#include <iostream>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;



int main()
{

	//create pipe
	int pipefd[2];
	
	if (pipe(pipefd) == -1)
	{
		cout<<"Error in pipe \n";
	}
	
	
	int n;
	cout<<" Enter a positive integer number! "<<endl;
	cin>>n;
	
	if (n < 0)
	{
		cout<<" Please pick a positive number! "<<endl;
	}
	
	else
	{
		for (int i=0; i<n;i++)
		{
			pid_t pid = fork();
			
			if (pid==0)  //child process
			{
				srand(time(NULL) + i);
				
				int randomNumbers = rand() % 10 + 1;
				
				
				
				close (pipefd[0]);  //closing read pipe
				
				write(pipefd[1],&randomNumbers,sizeof(randomNumbers));
				//writing
				
				return 0;
			}
			
		}
		
		//parent process
		close(pipefd[1]);
		
		//keep a count of numbers
		int numberCount[100] = {0};  //100 as a placeholder	
		
		for (int i=0; i<n; i++)
		{
			int guessnumber;
			read(pipefd[0],&guessnumber,sizeof(guessnumber));
			numberCount[guessnumber]++;
		}
		
		//close this pipe
		close(pipefd[0]);
		
		int maxnumber = 0;
		int maxchilds = 0;  //bascailly tells which child guesses highest number (i guess)
		
		for (int i=0; i<n;i++)
		{
			if (numberCount[i] > maxchilds)
			{
				maxchilds = numberCount[i];
				maxnumber = i;
			}
		}
		
		
		cout<< maxnumber <<" is the highest number guesses by " << maxchilds <<endl;
		
		 
		for (int i = 0; i < n; i++)
    		{
        		wait(NULL);
    		}

    		return 0;	
	}

}